﻿Imports System.Data.SqlClient
Imports System.Web.Services
Imports Newtonsoft.Json
Imports System.Web.Script.Services
Imports System.IO

Public Class _Default
    Inherits System.Web.UI.Page
    Private strImage As String = String.Empty
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DisplayEmployeeList()
        End If
    End Sub

    Protected Sub GetEmployee(ByVal employeeId As Integer)
        Dim emp As New employee
        Dim conn As SqlConnection = New SqlConnection("server=chris-pc\tidus; database=demo; Integrated Security=true;")
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader

        With cmd
            .Connection = conn
            .CommandType = CommandType.Text
            .CommandText = "SELECT [employee_id],[first_name],[mid_name],[last_name] " & _
                           ",[birth_date],[gender],[date_hired],[date_resigned] " +
                           ",[contact_no],[email],[photo] FROM [employees] where employee_id = @employee_id"
            .Parameters.Add("@employee_id", SqlDbType.Int).Value = employeeId
        End With

        Try
            conn.Open()
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                ClearFields()
                Dim birthDate As String
                Dim hiredDate As String
                Dim resignedDate As String
                While dr.Read
                    txtEmpId.Text = dr("employee_id")
                    txtFName.Text = If(dr("first_name"), "")
                    txtMName.Text = If(dr("mid_name"), "")
                    txtLName.Text = If(dr("last_name"), "")

                    birthDate = If(IsDBNull(dr("birth_date")), "", Format(dr("birth_date"), "MM/dd/yyyy"))
                    txtBDay.Text = birthDate
                    'UpdateDatePicker("txtBDay", birthDate)

                    hiredDate = If(IsDBNull(dr("date_hired")), "", Format(dr("date_hired"), "MM/dd/yyyy"))
                    txtHireDate.Text = hiredDate
                    'UpdateDatePicker("txtHireDate", hiredDate)

                    resignedDate = If(IsDBNull(dr("date_resigned")), "", Format(dr("date_resigned"), "MM/dd/yyyy"))
                    txtResignedDate.Text = resignedDate
                    'UpdateDatePicker("txtResignedDate", resignedDate)

                    txtContact.Text = If(dr("contact_no"), "")
                    txtEmail.Text = If(dr("email"), "")

                    If dr("gender") = "Male" Then
                        optMale.Checked = True
                    Else
                        optFemale.Checked = True
                    End If

                    Dim sb As New StringBuilder()

                    sb.Append("SetImage('")
                    If dr("photo").ToString().Trim() <> "" Then              
                        sb.Append("data:image/png;base64," & System.Text.Encoding.UTF8.GetString(dr("photo")).ToString())
                    Else
                        sb.Append("images/default_test.jpg")
                    End If
                    sb.Append("');ShowModal();")
                    CallJSFunctions(sb.ToString())

                End While
            End If
        Catch ex As Exception
            Throw
        Finally
            conn.Close()
            conn.Dispose()
        End Try
    End Sub

    Protected Sub DisplayEmployeeList()

        Dim conn As SqlConnection = New SqlConnection("server=chris-pc\tidus; database=demo; Integrated Security=true;")
        Dim cmd As New SqlCommand
        Dim da As New SqlDataAdapter
        Dim dtContacts As New DataTable
        Dim sql As String = ""

        sql = "SELECT [employee_id],[first_name] + ' ' + isnull([mid_name], '') + ' ' + [last_name] as employee_name " & _
                           ",[birth_date],[gender],[date_hired],[date_resigned] " +
                           ",[contact_no],[email],[photo] FROM [employees] "

        If txtSearch.Text.Trim() <> "" Then
            sql &= " where first_name + ' ' + isnull(mid_name, '') + ' ' + last_name like '%'+@search+'%'" & _
                   " or first_name + ' ' + last_name like'%'+@search+'%'" & _
                   " or last_name + ', ' + first_name + ' ' + isnull(mid_name, '') like'%'+@search+'%'"
        End If
        With cmd
            .Connection = conn
            .CommandType = CommandType.Text
            .CommandText = sql

            If txtSearch.Text.Trim() <> "" Then
                .Parameters.Add("@search", SqlDbType.VarChar).Value = txtSearch.Text.Trim()
            End If
        End With
        da.SelectCommand = cmd
        da.Fill(dtContacts)

        GridView1.DataSource = dtContacts
        GridView1.DataBind()

    End Sub

    Protected Sub Save_Details()
        Dim conn As SqlConnection = New SqlConnection("server=chris-pc\tidus; database=demo; Integrated Security=true;")
        Dim cmd As New SqlCommand

        With cmd
            .Connection = conn
            .CommandType = CommandType.Text

            If txtEmpId.Text.Trim() = "" Then
                .CommandText = "insert into employees([first_name], [mid_name], [last_name] " & _
                               ",[birth_date],[gender],[date_hired],[date_resigned] " & _
                               ",[contact_no],[email],[photo]) " & _
                               "values (@first_name, @mid_name, @last_name, @birth_date, " & _
                               "@gender, @date_hired, @date_resigned, @contact_no, @email, @photo)"
            Else
                .CommandText = "update employees set [first_name] = @first_name, [mid_name] = mid_name, " & _
                               "[last_name] = @last_name, [birth_date] = @birth_date, [gender] = @gender, " & _
                               "[date_hired] = @date_hired,[date_resigned] = @date_resigned , " & _
                               "[contact_no] = @contact_no, [email] = @email, [photo] = @photo " & _
                               "where employee_id = @employee_id"

                .Parameters.Add("@employee_id", SqlDbType.Int).Value = Convert.ToInt16(txtEmpId.Text.Trim())
            End If

            .Parameters.Add("@first_name", SqlDbType.VarChar).Value = txtFName.Text.Trim()
            .Parameters.Add("@mid_name", SqlDbType.VarChar).Value = txtMName.Text.Trim()
            .Parameters.Add("@last_name", SqlDbType.VarChar).Value = txtLName.Text.Trim()
            .Parameters.Add("@birth_date", SqlDbType.DateTime).Value = If(txtBDay.Text.Trim() <> "", txtBDay.Text.Trim(), DBNull.Value)
            If optMale.Checked Then
                .Parameters.Add("@gender", SqlDbType.VarChar).Value = "Male"
            Else
                .Parameters.Add("@gender", SqlDbType.VarChar).Value = "Female"
            End If
            .Parameters.Add("@date_hired", SqlDbType.DateTime).Value = If(txtHireDate.Text.Trim() <> "", txtHireDate.Text.Trim(), DBNull.Value)
            .Parameters.Add("@date_resigned", SqlDbType.DateTime).Value = If(txtResignedDate.Text.Trim() <> "", txtResignedDate.Text.Trim(), DBNull.Value)
            .Parameters.Add("@contact_no", SqlDbType.VarChar).Value = txtContact.Text.Trim()
            .Parameters.Add("@email", SqlDbType.VarChar).Value = txtEmail.Text.Trim()
            .Parameters.Add("@photo", SqlDbType.VarBinary).Value = System.Text.Encoding.UTF8.GetBytes(hfImage.Value)

        End With

        Try

            conn.Open()
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            Throw
        Finally
            conn.Close()
        End Try

    End Sub
    Protected Sub Delete_Rcord(ByVal employeeId As Integer)
        Dim conn As SqlConnection = New SqlConnection("server=chris-pc\tidus; database=demo; Integrated Security=true;")
        Dim cmd As New SqlCommand

        With cmd
            .Connection = conn
            .CommandType = CommandType.Text
            .CommandText = "delete from employees where employee_id = @employee_id"

            .Parameters.Add("@employee_id", SqlDbType.Int).Value = Convert.ToInt16(employeeId)
        End With

        Try

            conn.Open()
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            Throw
        Finally
            conn.Close()
        End Try
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Save_Details()
        DisplayEmployeeList()
        ShowModalDialog(False, "Record has been updated.")
    End Sub

    Protected Sub GridView1_PageIndexChanged(sender As Object, e As EventArgs) Handles GridView1.PageIndexChanged
        DisplayEmployeeList()
    End Sub

    Protected Sub GridView1_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        GridView1.DataBind()
    End Sub


    Protected Sub GridView1_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand

        Select Case e.CommandName
            Case "select"
                ClearFields()
                GetEmployee(e.CommandArgument)
        End Select
    End Sub

    Protected Sub ShowModalDialog(ByVal value As Boolean, Optional ByVal message As String = "")

        If value Then
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", "ShowModal()", True)
        Else
            Dim script As String = ""
            script = String.Format("CloseModal('{0}');", message)
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", script, True)
        End If

    End Sub

    Protected Sub CallJSFunctions(ByVal script As String)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", script, True)

    End Sub

    Protected Sub ClearFields()
        txtEmpId.Text = ""
        txtFName.Text = ""
        txtMName.Text = ""
        txtLName.Text = ""
        txtBDay.Text = ""
        txtHireDate.Text = ""
        txtResignedDate.Text = ""
        txtContact.Text = ""
        txtEmail.Text = ""
        optMale.Checked = True
    End Sub

    Protected Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim sc As New StringCollection()
        Dim id As String = String.Empty
        For i As Integer = 0 To GridView1.Rows.Count - 1
            Dim cb As CheckBox = DirectCast(GridView1.Rows(i).Cells(6).FindControl("chkDelete"), CheckBox)
            If cb IsNot Nothing Then
                If cb.Checked Then
                    Dim hf As HiddenField = DirectCast(GridView1.Rows(i).Cells(6).FindControl("hfEmpId"), HiddenField)
                    id = hf.Value
                    sc.Add(id)
                End If
            End If
        Next
        For Each item As String In sc
            Delete_Rcord(item)
        Next
        DisplayEmployeeList()
        ShowMessageBox("Record has been deleted.")
    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DisplayEmployeeList()
    End Sub

    Protected Sub ShowMessageBox(ByVal message As String)
        Dim script As String = ""
        script = String.Format("alert('{0}');", message)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", script, True)
    End Sub

End Class