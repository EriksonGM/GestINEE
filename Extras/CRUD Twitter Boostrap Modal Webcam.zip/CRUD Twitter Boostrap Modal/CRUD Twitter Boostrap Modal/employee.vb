﻿Public Class employee

    Public Property EmployeeId As String
    Public Property FirstName As String
    Public Property MidName As String
    Public Property LastName As String
    Public Property Birthdate As String
    Public Property Gender As String
    Public Property DateHired As String
    Public Property DateResigend As String
    Public Property ContactNo As String
    Public Property Email As String
    Public Property Photo As String

End Class
